cd /root/plugin/plugin-dev
python exec-plugin-dev.py $1
