25a26
>     bool isTreeCodeValidTrace(const std::string& treeCode);
