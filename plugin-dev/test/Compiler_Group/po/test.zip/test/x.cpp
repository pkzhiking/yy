int main()
{
    dfa;
}
