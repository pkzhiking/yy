int fun()
{}
