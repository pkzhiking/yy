#include "a.h"

int main()
{
    int a = A;
    return a;
}
