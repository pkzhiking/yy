#ifndef A_H
#define A_H

#define A 3

#endif
