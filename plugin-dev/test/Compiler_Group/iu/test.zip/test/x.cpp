#include "luanxiede.h"

int main()
{
    int x = AF;
    return 0;
}
