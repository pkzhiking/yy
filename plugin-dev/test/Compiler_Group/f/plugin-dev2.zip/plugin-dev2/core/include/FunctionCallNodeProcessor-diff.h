17a18
>     static string getParameterName(GNode* node);
