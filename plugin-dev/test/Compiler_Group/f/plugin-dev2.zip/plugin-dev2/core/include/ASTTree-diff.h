34a35,36
>         void _setHashCode(unsigned int);
>         unsigned int _getHashCode() const;
43a46
>         unsigned int mHashCode;
