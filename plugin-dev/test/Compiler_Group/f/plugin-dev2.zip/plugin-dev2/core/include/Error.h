/*
 * Error.h
 *
 *  Created on: Apr 7, 2012
 *      Author: Guo Jiuliang
 */
#ifndef ERROR_H
#define ERROR_H
#include <stdexcept>
#include <exception>
using std::logic_error;
class Error
{

};
#endif /* ERROR_H */
