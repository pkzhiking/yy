int mymax(int pa, int pb, int pc)
{
	return pa > pb ? pa : pb;
}


