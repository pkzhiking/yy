/*
 * gele.cpp
 *
 *  Created on: May 3, 2012
 *      Author: Guo Jiuliang
 */


int main()
{
	int min =0;
	int max = 10;

	int val =5;
	if(val <= max && val >= min) {
		val =10;
	}
	return 0;
}

